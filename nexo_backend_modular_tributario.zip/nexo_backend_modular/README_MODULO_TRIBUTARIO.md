# Módulo Tributário separado

## Arquivos criados

- `app/modules/tributario/router.py`: rotas HTTP
- `app/modules/tributario/service.py`: integração Tiny + Supabase e regras
- `app/modules/tributario/schemas.py`: modelos de entrada
- `main.py`: arquivo original com apenas o `include_router`

## Rotas novas

- `POST /tributario/sync-produtos`
- `GET /tributario/resumo`
- `GET /tributario/produtos`
- `GET /tributario/lotes`
- `GET /tributario/lote/{numero}`
- `PATCH /tributario/produto/{produto_id}`

## Primeiro teste no Swagger

Para evitar uma execução longa no primeiro teste:

`POST /tributario/sync-produtos?filial=sp&tamanho_lote=50&detalhar=true&limite_detalhes=10&max_paginas=1`

Depois consulte:

- `GET /tributario/resumo?filial=sp`
- `GET /tributario/lotes?filial=sp`
- `GET /tributario/produtos?filial=sp&limite=100`

## Deploy

Mantenha a pasta `app` no mesmo nível do `main.py` no GitHub/Railway.
O comando de inicialização continua sendo, por exemplo:

`uvicorn main:app --host 0.0.0.0 --port $PORT`

## Observação

A análise por IA ainda não foi ativada. Esta entrega importa, organiza em lotes e prepara a fila tributária com segurança.
